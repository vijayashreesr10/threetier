$(document).ready(function(){
    $("#sumbitButton").click(function (event) {
        event.preventDefault();
        window.location = mainAppUrl;
    });
});