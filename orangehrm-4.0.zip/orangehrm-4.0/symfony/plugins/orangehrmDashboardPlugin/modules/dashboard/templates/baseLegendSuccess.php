<script type="text/css">
    .task-list-group-panel-menu_holder{
    margin:0;
    padding: 5px;
    padding-top: 8px;
    /*background:white;*/
    overflow-y:auto; /* make the overflow as hidden, like a mask layer*/
    overflow-x: hidden;
    height:100%; /* Height of the menu holder, same as the container*/
    position:relative;
    /*width:100%;*/
}
</script>
<div id="task-list-group-panel-menu_holder-legend" class="task-list-group-panel-menu_holder">
    <div id="<?php echo "div_legend_pim_employee_distribution"; ?>_legend" style="width:auto;display:block;float:left;"></div>
</div>