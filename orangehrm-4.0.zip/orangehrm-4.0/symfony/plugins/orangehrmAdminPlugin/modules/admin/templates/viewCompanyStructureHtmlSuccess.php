<?php
$tree->render();
$tree->printJavascript();
?>